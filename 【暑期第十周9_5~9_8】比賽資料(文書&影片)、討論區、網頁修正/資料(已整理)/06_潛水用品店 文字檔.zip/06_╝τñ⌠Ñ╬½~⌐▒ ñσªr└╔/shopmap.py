import pandas as pd

df = pd.read_csv("./地圖打點/潛水用品店.csv", encoding="utf-8")
df.fillna('null', inplace=True)

result = "["

for index, row in df.iterrows():
    result += '["ch_name"=>"{0}","en_name"=>"{1}","address"=>"{2}","url"=>"{3}","work_start_from"=>"{4}","work_end_to"=>"{5}","transform_note"=>"{6}","area"=>"{7}","location"=>"{8}","lat"=>"{9}","lng"=>"{10}","star_rating"=>"{11}","reviews"=>"{12}","AI_reviews"=>"{13}","reviews_url"=>"{14}","preview_img_url"=>"{15}"]'.format(
        row["店家名稱"], row["店家名稱(英)"], row["地址"],  row["連結"], row["營業時間(起)"], row["營業時間(迄)"], row["交通建議"], row["地區"], row[
            "縣市"], row["緯度"], row["經度"], row["星級"], row["評論數量"], row["AI評論"], row["評論連結"], row["潛水用品店預覽圖路徑"]
    )

    if index < df.shape[0] - 1:
        result += ","

result += "]"

print(result)
