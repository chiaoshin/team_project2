<?phpDiving
// 1.空格
// 2./n改/n/n


?>